--[[
    ox_inventory Admin Config UI
    Adds /oxconfig for trusted admins to edit whitelisted ox_inventory data files
    and manage PNG images inside web/images.

    SECURITY:
    - Never exposes arbitrary file paths.
    - Only data/*.lua and web/images/*.png are writable.
    - Requires ACE/framework admin permission.
]]

local resource = shared and shared.resource or GetCurrentResourceName()
local maxConfigBytes = GetConvarInt('inventory:oxconfig_max_config_kb', 2048) * 1024
local maxImageBytes = GetConvarInt('inventory:oxconfig_max_image_kb', 2048) * 1024

local dataFiles = {
    { key = 'items', label = 'Items', path = 'data/items.lua', type = 'items' },
    { key = 'weapons', label = 'Weapons', path = 'data/weapons.lua', type = 'weapons' },
    { key = 'shops', label = 'Shops', path = 'data/shops.lua', type = 'shops' },
    { key = 'crafting', label = 'Crafting', path = 'data/crafting.lua', type = 'config' },
    { key = 'evidence', label = 'Evidence', path = 'data/evidence.lua', type = 'config' },
    { key = 'licenses', label = 'Licenses', path = 'data/licenses.lua', type = 'config' },
    { key = 'stashes', label = 'Stashes', path = 'data/stashes.lua', type = 'config' },
    { key = 'vehicles', label = 'Vehicles', path = 'data/vehicles.lua', type = 'config' },
    { key = 'animations', label = 'Animations', path = 'data/animations.lua', type = 'config' },
}

local dataFileByPath = {}
for i = 1, #dataFiles do
    dataFileByPath[dataFiles[i].path] = dataFiles[i]
end

local imageRegistryPath = 'web/images/oxconfig_images.json'
local settingsPath = 'oxconfig_settings.json'
local restartHelperResource = GetConvar('inventory:restarthelper', 'ox_inventory_restart_helper')
local imageSet = {}
local restartQueued = false

-- Forward declarations for the live map parser used by dashboard().
-- Lua resolves locals lexically, so these must exist before dashboard() is compiled.
local mapConfig
local parseShopLocations

local function notify(source, msg, notifyType)
    TriggerClientEvent('ox_inventory:oxconfig:notify', source, msg, notifyType or 'inform')
end

local function hasQBCorePermission(source)
    if GetResourceState('qb-core') ~= 'started' then return false end

    local ok, QBCore = pcall(function()
        return exports['qb-core']:GetCoreObject()
    end)

    if not ok or not QBCore or not QBCore.Functions then return false end

    local checks = { 'god', 'admin' }
    for i = 1, #checks do
        local success, allowed = pcall(QBCore.Functions.HasPermission, source, checks[i])
        if success and allowed then return true end
    end

    return false
end

local function hasQBXPermission(source)
    if GetResourceState('qbx_core') ~= 'started' then return false end

    local ok, player = pcall(function()
        return exports.qbx_core:GetPlayer(source)
    end)

    if ok and player then
        local permissions = player.PlayerData and player.PlayerData.permissions or player.permissions
        if type(permissions) == 'table' then
            return permissions.admin or permissions.god or permissions.owner or permissions.mod
        end
    end

    return false
end


local function hasAzPermission(source)
    if GetResourceState('Az-Framework') ~= 'started' then return false end

    local ok, allowed = pcall(function()
        return exports['Az-Framework']:isAdmin(source)
    end)

    return ok and allowed == true
end

local function isAdmin(source)
    if source == 0 then return true end

    local ace = GetConvar('inventory:oxconfig_ace', 'ox_inventory.oxconfig')

    return IsPlayerAceAllowed(source, ace)
        or IsPlayerAceAllowed(source, 'command.oxconfig')
        or IsPlayerAceAllowed(source, 'command.oxconfigrestart')
        or IsPlayerAceAllowed(source, 'command')
        or IsPlayerAceAllowed(source, 'admin')
        or hasQBCorePermission(source)
        or hasQBXPermission(source)
        or hasAzPermission(source)
end

local function readFile(path)
    return LoadResourceFile(resource, path)
end

local function writeFile(path, content)
    return SaveResourceFile(resource, path, content, #content)
end


local function boolConvar(name, default)
    return GetConvarInt(name, default and 1 or 0) == 1
end

local function intConvar(name, default)
    return GetConvarInt(name, default)
end

local function decodeConvarList(name, fallbackJson)
    local ok, decoded = pcall(json.decode, GetConvar(name, fallbackJson))
    if ok and type(decoded) == 'table' then return decoded end
    return json.decode(fallbackJson)
end

local function copyArray(value, fallback)
    local out = {}

    if type(value) == 'table' then
        for _, entry in pairs(value) do
            if type(entry) == 'string' and entry:gsub('%s+', '') ~= '' then
                out[#out + 1] = entry:gsub('^%s+', ''):gsub('%s+$', '')
            elseif type(entry) == 'number' then
                out[#out + 1] = entry
            end
        end
    elseif type(value) == 'string' then
        local trimmed = value:gsub('^%s+', ''):gsub('%s+$', '')
        if trimmed:sub(1, 1) == '[' then
            local ok, decoded = pcall(json.decode, trimmed)
            if ok then return copyArray(decoded, fallback) end
        end

        for entry in trimmed:gmatch('[^,%s]+') do
            out[#out + 1] = entry
        end
    end

    if #out == 0 and fallback then return copyArray(fallback) end
    return out
end

local function dynamicSettingsDefaults()
    return {
        enabled = false,
        framework = GetConvar('inventory:framework', 'esx'),
        slots = intConvar('inventory:slots', 50),
        weight = intConvar('inventory:weight', 30000),
        dropslots = intConvar('inventory:dropslots', intConvar('inventory:slots', 50)),
        dropweight = intConvar('inventory:dropweight', intConvar('inventory:weight', 30000)),
        target = boolConvar('inventory:target', false),
        police = decodeConvarList('inventory:police', '["police", "sheriff"]'),
        keys = decodeConvarList('inventory:keys', '["F2", "K", "TAB"]'),
        enablekeys = decodeConvarList('inventory:enablekeys', '[249]'),
        screenblur = boolConvar('inventory:screenblur', true),
        itemnotify = boolConvar('inventory:itemnotify', true),
        weaponnotify = boolConvar('inventory:weaponnotify', true),
        weaponanims = boolConvar('inventory:weaponanims', true),
        weaponmismatch = boolConvar('inventory:weaponmismatch', true),
        autoreload = boolConvar('inventory:autoreload', false),
        giveplayerlist = boolConvar('inventory:giveplayerlist', false),
        enablestealcommand = boolConvar('inventory:enablestealcommand', true),
        nativeWeaponWheel = boolConvar('inventory:nativeweaponwheel', false) or boolConvar('inventory:weaponwheel', false),
        disableWeaponItems = boolConvar('inventory:disableweaponitems', false),
        disableweapons = boolConvar('inventory:disableweapons', false),
        suppresspickups = boolConvar('inventory:suppresspickups', true),
        networkdumpsters = boolConvar('inventory:networkdumpsters', false),
        randomprices = boolConvar('inventory:randomprices', false),
        randomloot = boolConvar('inventory:randomloot', true),
        bulkstashsave = boolConvar('inventory:bulkstashsave', true),
        evidencegrade = intConvar('inventory:evidencegrade', 2),
        trimplate = boolConvar('inventory:trimplate', true),
        dropprops = boolConvar('inventory:dropprops', false),
        dropmodel = GetConvar('inventory:dropmodel', 'prop_med_bag_01b'),
        imagepath = GetConvar('inventory:imagepath', ('nui://%s/web/images'):format(resource)),
    }
end

local function readSettingsFile()
    local raw = readFile(settingsPath)
    if not raw or raw == '' then return {} end

    local ok, decoded = pcall(json.decode, raw)
    if ok and type(decoded) == 'table' then return decoded end

    return {}
end

local function currentSettings()
    local settings = dynamicSettingsDefaults()
    local saved = readSettingsFile()

    for key, value in pairs(saved) do
        if key:sub(1, 1) ~= '_' then settings[key] = value end
    end

    settings.police = copyArray(settings.police, { 'police', 'sheriff' })
    settings.keys = copyArray(settings.keys, { 'F2', 'K', 'TAB' })
    settings.enablekeys = copyArray(settings.enablekeys, { 249 })

    if settings.nativeWeaponWheel then
        settings.disableweapons = true
        settings.disableWeaponItems = true
        settings.weaponmismatch = false
    end

    return settings
end

local function boolValue(value)
    if type(value) == 'boolean' then return value end
    if type(value) == 'number' then return value ~= 0 end
    if type(value) == 'string' then
        value = value:lower()
        return value == '1' or value == 'true' or value == 'yes' or value == 'on'
    end
    return false
end

local function boundedInt(value, min, max, fallback)
    value = tonumber(value) or fallback
    value = math.floor(value)
    if value < min then value = min end
    if value > max then value = max end
    return value
end

local function cleanString(value, fallback, maxLen)
    value = tostring(value or fallback or '')
    value = value:gsub('\r', ''):gsub('\n', ''):gsub('^%s+', ''):gsub('%s+$', '')
    if value == '' then value = tostring(fallback or '') end
    if maxLen and #value > maxLen then value = value:sub(1, maxLen) end
    return value
end

local function cleanSettingsPayload(payload)
    if type(payload) ~= 'table' then return nil, 'invalid_payload' end

    local current = currentSettings()
    local allowedFrameworks = { auto = true, az = true, esx = true, qbx = true, ox = true, nd = true }
    local framework = cleanString(payload.framework, current.framework, 16):lower()
    if framework == 'azure' or framework == 'az-framework' or framework == 'azframework' then framework = 'az' end
    if not allowedFrameworks[framework] then return nil, 'Invalid framework. Use auto, az, esx, qbx, ox, or nd.' end

    local settings = {
        enabled = true,
        framework = framework,
        slots = boundedInt(payload.slots, 1, 200, current.slots or 50),
        weight = boundedInt(payload.weight, 1, 2000000, current.weight or 30000),
        dropslots = boundedInt(payload.dropslots, 1, 200, payload.slots or current.dropslots or current.slots or 50),
        dropweight = boundedInt(payload.dropweight, 1, 2000000, payload.weight or current.dropweight or current.weight or 30000),
        target = boolValue(payload.target),
        police = copyArray(payload.police, current.police),
        keys = copyArray(payload.keys, current.keys),
        enablekeys = copyArray(payload.enablekeys, current.enablekeys),
        screenblur = boolValue(payload.screenblur),
        itemnotify = boolValue(payload.itemnotify),
        weaponnotify = boolValue(payload.weaponnotify),
        weaponanims = boolValue(payload.weaponanims),
        weaponmismatch = boolValue(payload.weaponmismatch),
        autoreload = boolValue(payload.autoreload),
        giveplayerlist = boolValue(payload.giveplayerlist),
        enablestealcommand = boolValue(payload.enablestealcommand),
        nativeWeaponWheel = boolValue(payload.nativeWeaponWheel),
        disableWeaponItems = boolValue(payload.disableWeaponItems),
        disableweapons = boolValue(payload.disableweapons),
        suppresspickups = boolValue(payload.suppresspickups),
        networkdumpsters = boolValue(payload.networkdumpsters),
        randomprices = boolValue(payload.randomprices),
        randomloot = boolValue(payload.randomloot),
        bulkstashsave = boolValue(payload.bulkstashsave),
        evidencegrade = boundedInt(payload.evidencegrade, 0, 20, current.evidencegrade or 2),
        trimplate = boolValue(payload.trimplate),
        dropprops = boolValue(payload.dropprops),
        dropmodel = cleanString(payload.dropmodel, current.dropmodel or 'prop_med_bag_01b', 96),
        imagepath = cleanString(payload.imagepath, current.imagepath or ('nui://%s/web/images'):format(resource), 180),
        updatedAt = os.date('!%Y-%m-%dT%H:%M:%SZ'),
    }

    if settings.nativeWeaponWheel then
        settings.disableWeaponItems = true
        settings.disableweapons = true
        settings.weaponmismatch = false
        settings.suppresspickups = false
    end

    return settings
end

local function compactValue(value)
    if type(value) == 'boolean' then return value and '1' or '0' end
    if type(value) == 'table' then return json.encode(value) end
    return tostring(value)
end

local function applySettingsConvars(settings)
    local keyMap = {
        framework = 'inventory:framework', slots = 'inventory:slots', weight = 'inventory:weight',
        dropslots = 'inventory:dropslots', dropweight = 'inventory:dropweight', target = 'inventory:target',
        police = 'inventory:police', keys = 'inventory:keys', enablekeys = 'inventory:enablekeys',
        screenblur = 'inventory:screenblur', itemnotify = 'inventory:itemnotify', weaponnotify = 'inventory:weaponnotify',
        weaponanims = 'inventory:weaponanims', weaponmismatch = 'inventory:weaponmismatch', autoreload = 'inventory:autoreload',
        giveplayerlist = 'inventory:giveplayerlist', enablestealcommand = 'inventory:enablestealcommand',
        nativeWeaponWheel = 'inventory:nativeweaponwheel', disableWeaponItems = 'inventory:disableweaponitems',
        disableweapons = 'inventory:disableweapons', suppresspickups = 'inventory:suppresspickups',
        networkdumpsters = 'inventory:networkdumpsters', randomprices = 'inventory:randomprices', randomloot = 'inventory:randomloot',
        bulkstashsave = 'inventory:bulkstashsave', evidencegrade = 'inventory:evidencegrade', trimplate = 'inventory:trimplate',
        dropprops = 'inventory:dropprops', dropmodel = 'inventory:dropmodel', imagepath = 'inventory:imagepath',
    }

    for key, convar in pairs(keyMap) do
        if settings[key] ~= nil then ExecuteCommand(('setr %s %s'):format(convar, compactValue(settings[key]))) end
    end

    -- Backwards-compatible alias used by many server.cfg examples.
    if settings.nativeWeaponWheel ~= nil then
        ExecuteCommand(('setr inventory:weaponwheel %s'):format(settings.nativeWeaponWheel and '1' or '0'))
    end
end

local function saveSettings(settings)
    local old = readFile(settingsPath) or ''
    if old ~= '' then writeFile(('%s.bak.%s'):format(settingsPath, os.time()), old) end

    local ok = writeFile(settingsPath, json.encode(settings))
    if not ok then return false, 'save_failed' end

    applySettingsConvars(settings)
    shared.oxconfig = settings

    return true
end

local function safeDataPath(path)
    if type(path) ~= 'string' then return nil end
    return dataFileByPath[path] and path or nil
end

local function cleanImageName(name)
    if type(name) ~= 'string' then return nil end

    name = name:gsub('\\', '/'):match('([^/]+)$') or name
    name = name:gsub('%s+', '_'):gsub('[^%w%._%-]', ''):lower()

    if not name:match('%.png$') then
        name = name .. '.png'
    end

    if name == '.png' or name:find('%.%.', 1, true) or #name > 96 then
        return nil
    end

    return name
end

local function imagePath(name)
    local clean = cleanImageName(name)
    if not clean then return nil end
    return ('web/images/%s'):format(clean), clean
end

local b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local b64lookup = {}
for i = 1, #b64chars do
    b64lookup[b64chars:sub(i, i)] = i - 1
end

local function decodeBase64(data)
    if type(data) ~= 'string' then return nil end

    data = data:gsub('[^A-Za-z0-9%+/%=]', '')

    local out, buffer, bits = {}, 0, 0
    local n = 0

    for i = 1, #data do
        local c = data:sub(i, i)

        if c == '=' then
            break
        end

        local value = b64lookup[c]
        if value then
            buffer = buffer * 64 + value
            bits = bits + 6

            while bits >= 8 do
                bits = bits - 8
                local byte = math.floor(buffer / (2 ^ bits)) % 256
                n = n + 1
                out[n] = string.char(byte)
            end
        end
    end

    return table.concat(out)
end

local function registryList()
    local raw = readFile(imageRegistryPath)
    if not raw or raw == '' then return {} end

    local ok, parsed = pcall(json.decode, raw)
    if ok and type(parsed) == 'table' then
        return parsed
    end

    return {}
end

local function saveRegistry()
    local list, n = {}, 0

    for name in pairs(imageSet) do
        n = n + 1
        list[n] = name
    end

    table.sort(list)
    writeFile(imageRegistryPath, json.encode(list))
end

local function addImageName(name)
    local clean = cleanImageName(name)
    if clean then imageSet[clean] = true end
end

local function collectImagesFromText(text)
    if type(text) ~= 'string' then return end

    for image in text:gmatch("['\"]([^'\"]+%.png)['\"]") do
        addImageName(image)
    end
end


local function collectImagesFromDisk()
    if not io or not io.popen then return end

    local root = GetResourcePath(resource)
    if not root then return end

    local isWindows = package and package.config and package.config:sub(1, 1) == '\\'
    local cmd

    if isWindows then
        cmd = ('dir /b "%s\\web\\images\\*.png" 2>nul'):format(root)
    else
        cmd = ('ls -1 "%s/web/images" 2>/dev/null'):format(root:gsub('"', '\\"'))
    end

    local ok, handle = pcall(io.popen, cmd)
    if not ok or not handle then return end

    for line in handle:lines() do
        if line and line:lower():match('%.png$') then
            addImageName(line)
        end
    end

    handle:close()
end

local function refreshImageSet()
    imageSet = {}

    local reg = registryList()
    for i = 1, #reg do
        addImageName(reg[i])
    end

    for i = 1, #dataFiles do
        collectImagesFromText(readFile(dataFiles[i].path))
    end

    collectImagesFromDisk()
end

local function listImages()
    refreshImageSet()

    local list, n = {}, 0

    for name in pairs(imageSet) do
        local path = ('web/images/%s'):format(name)
        local content = readFile(path)

        n = n + 1
        list[n] = {
            name = name,
            path = path,
            exists = content ~= nil,
            size = content and #content or 0,
            url = ('nui://%s/web/images/%s'):format(resource, name)
        }
    end

    table.sort(list, function(a, b) return a.name < b.name end)
    return list
end

local function quotedValue(text, field)
    if type(text) ~= 'string' or type(field) ~= 'string' then return nil end

    local _, value = text:match(field .. "%s*=%s*(['\"])(.-)%1")
    return value
end

local function parseEntries(text, mode)
    local entries, n = {}, 0
    if type(text) ~= 'string' then return entries end

    local seen = {}
    local pos = 1

    while true do
        local a, b, _, key = text:find("%[(['\"])(.-)%1%]%s*=%s*{", pos)
        if not a then break end

        if key and key ~= '' and not seen[key] then
            seen[key] = true
            local slice = text:sub(b + 1, math.min(#text, b + 1200))
            local label = quotedValue(slice, 'label')
            local image = quotedValue(slice, 'image')
            local ammo = quotedValue(slice, 'ammoname')
            local weight = slice:match("weight%s*=%s*(%d+)")
            local description = quotedValue(slice, 'description')
            local stack = slice:match("stack%s*=%s*(false)") and false or true
            local close = slice:match("close%s*=%s*(false)") and false or true
            local consume = slice:match("consume%s*=%s*(%d+)")

            if image and not image:lower():match('%.png$') then image = nil end

            n = n + 1
            entries[n] = {
                name = key,
                label = label or key,
                image = image,
                ammo = ammo,
                weight = weight and tonumber(weight) or nil,
                description = description,
                stack = stack,
                close = close,
                consume = consume and tonumber(consume) or nil,
                mode = mode
            }
        end

        pos = b + 1
    end

    table.sort(entries, function(a, b) return a.name < b.name end)
    return entries
end

local function parseShopEntries(text)
    local entries, n = {}, 0
    if type(text) ~= 'string' then return entries end

    local candidates = {}
    for key in text:gmatch('\n%s*([%w_]+)%s*=%s*{') do
        if key ~= 'blip' and key ~= 'inventory' and key ~= 'locations' and key ~= 'targets' and key ~= 'metadata' then
            candidates[#candidates + 1] = key
        end
    end

    for i = 1, #candidates do
        local key = candidates[i]
        local start = text:find('\n%s*' .. key .. '%s*=%s*{')
        if start then
            local slice = text:sub(start, math.min(#text, start + 1600))
            local label = quotedValue(slice, 'name')
            local itemCount = 0
            local inventoryBlock = slice:match('inventory%s*=%s*{%s*(.-)%s*}%s*,%s*locations') or ''
            for _ in inventoryBlock:gmatch("name%s*=") do itemCount = itemCount + 1 end

            n = n + 1
            entries[n] = {
                name = key,
                label = label or key,
                itemCount = itemCount,
                mode = 'shops'
            }
        end
    end

    table.sort(entries, function(a, b) return a.name < b.name end)
    return entries
end

local function dashboard()
    local itemsText = readFile('data/items.lua') or ''
    local weaponsText = readFile('data/weapons.lua') or ''
    local shopsText = readFile('data/shops.lua') or ''
    local items = parseEntries(itemsText, 'items')
    local weapons = parseEntries(weaponsText, 'weapons')
    local shops = parseShopEntries(shopsText)

    local images = listImages()
    local shopLocations = parseShopLocations(shopsText)

    return {
        files = dataFiles,
        images = images,
        counts = {
            items = #items,
            weapons = #weapons,
            shops = #shops,
            shopLocations = #shopLocations,
            images = #images,
        },
        items = items,
        weapons = weapons,
        shops = shops,
        shopLocations = shopLocations,
        mapConfig = mapConfig,
        settings = currentSettings(),
        settingsPath = settingsPath,
        resource = resource,
        maxConfigKb = math.floor(maxConfigBytes / 1024),
        maxImageKb = math.floor(maxImageBytes / 1024),
    }
end



-- No-code helper actions used by the Discord-style oxconfig UI.
-- These write controlled snippets into whitelisted files instead of requiring staff to type Lua.
local function luaString(value)
    value = tostring(value or '')
    value = value:gsub('\\', '\\\\'):gsub('\n', '\\n'):gsub('\r', ''):gsub("'", "\\'")
    return ("'%s'"):format(value)
end

local function cleanConfigKey(value, allowUpper)
    if type(value) ~= 'string' then return nil end
    value = value:gsub('%s+', '_'):gsub('[^%w_%-]', '')
    if not allowUpper then value = value:lower() end
    if value == '' or #value > 96 then return nil end
    return value
end

local function hasBracketEntry(text, key)
    if type(text) ~= 'string' or type(key) ~= 'string' then return false end

    for _, found in text:gmatch("%[(['\"])(.-)%1%]%s*=") do
        if found == key then return true end
    end

    return false
end

local function finalReturnBracePos(text)
    if type(text) ~= 'string' then return nil end
    return text:match('^.*()}%s*$')
end

local function ensureCommaBeforeInsert(text, insertPos)
    if type(text) ~= 'string' or type(insertPos) ~= 'number' then return text, insertPos end

    local before = text:sub(1, insertPos - 1)
    local i = #before

    while i > 0 and before:sub(i, i):match('%s') do i = i - 1 end

    if i > 0 and before:sub(i, i) == '}' then
        text = text:sub(1, i) .. ',' .. text:sub(i + 1)
        insertPos = insertPos + 1
    end

    return text, insertPos
end

local function findClosingBrace(text, openPos)
    local depth = 0
    local i = openPos
    local quote = nil
    local escaped = false
    local lineComment = false
    local blockComment = false

    while i <= #text do
        local c = text:sub(i, i)
        local two = text:sub(i, i + 1)
        local four = text:sub(i, i + 3)

        if lineComment then
            if c == '\n' then lineComment = false end
        elseif blockComment then
            if two == ']]' then
                blockComment = false
                i = i + 1
            end
        elseif quote then
            if escaped then
                escaped = false
            elseif c == '\\' then
                escaped = true
            elseif c == quote then
                quote = nil
            end
        else
            if four == '--[[' then
                blockComment = true
                i = i + 3
            elseif two == '--' then
                lineComment = true
                i = i + 1
            elseif c == '\'' or c == '"' or c == '`' then
                quote = c
            elseif c == '{' then
                depth = depth + 1
            elseif c == '}' then
                depth = depth - 1
                if depth == 0 then return i end
            end
        end

        i = i + 1
    end

    return nil
end

local function writeWithBackup(path, oldContent, newContent)
    local backupPath = ('%s.bak.%s'):format(path, os.time())
    writeFile(backupPath, oldContent)

    local ok = writeFile(path, newContent)
    if not ok then return false, 'save_failed' end

    return true, backupPath
end

local function buildItemEntry(payload)
    local name = cleanConfigKey(payload.name, false)
    if not name then return nil, 'Invalid item name. Use letters, numbers, _ or - only.' end

    local label = tostring(payload.label or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if label == '' or #label > 96 then return nil, 'Item label is required.' end

    local weight = tonumber(payload.weight) or 0
    if weight < 0 then weight = 0 end
    weight = math.floor(weight)

    local image = cleanImageName(payload.image or '')
    if not payload.image or payload.image == '' then image = nil end

    local description = tostring(payload.description or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if #description > 240 then description = description:sub(1, 240) end

    local lines = {
        ('    [%s] = {'):format(luaString(name)),
        ('        label = %s,'):format(luaString(label)),
        ('        weight = %d,'):format(weight),
        ('        stack = %s,'):format(payload.stack == false and 'false' or 'true'),
        ('        close = %s,'):format(payload.close == false and 'false' or 'true'),
    }

    if payload.consume == 0 or payload.consume == '0' then
        lines[#lines + 1] = '        consume = 0,'
    end

    if description ~= '' then
        lines[#lines + 1] = ('        description = %s,'):format(luaString(description))
    end

    if image then
        lines[#lines + 1] = '        client = {'
        lines[#lines + 1] = ('            image = %s,'):format(luaString(image))
        lines[#lines + 1] = '        },'
    end

    lines[#lines + 1] = '    },'

    return name, table.concat(lines, '\n')
end

local function findItemEntryBlock(text, itemName)
    itemName = cleanConfigKey(itemName, false)
    if not itemName or type(text) ~= 'string' then return nil end

    local patterns = {
        "%[" .. luaString(itemName) .. "%]%s*=%s*{",
        "%[\"" .. itemName:gsub('([%^%$%(%)%%%.%[%]%*%+%-%?])', '%%%1') .. "\"%]%s*=%s*{",
    }

    local startPos
    for i = 1, #patterns do
        startPos = text:find(patterns[i])
        if startPos then break end
    end

    if not startPos then return nil end
    local brace = text:find('{', startPos, true)
    if not brace then return nil end
    local close = findClosingBrace(text, brace)
    if not close then return nil end

    return startPos, brace, close
end

local function upsertLuaField(block, key, luaValue)
    local replaced = false
    local pattern = '([\n\r%s]+)' .. key .. '%s*=%s*([^,\n}]+),?'

    block = block:gsub(pattern, function(prefix)
        if replaced then return nil end
        replaced = true
        return prefix .. key .. ' = ' .. luaValue .. ','
    end, 1)

    if replaced then return block end

    local open = block:find('{', 1, true)
    if not open then return block end
    return block:sub(1, open) .. ('\n        %s = %s,'):format(key, luaValue) .. block:sub(open + 1)
end

local function removeLuaField(block, key)
    return block:gsub('[\n\r]%s*' .. key .. '%s*=%s*[^,\n}]+,?', '', 1)
end

local function upsertClientImage(block, image)
    if not image or image == '' then
        return block:gsub('[\n\r]%s*image%s*=%s*[\'\"][^\'\"]+%.png[\'\"],?', '', 1)
    end

    local clientStart = block:find('client%s*=%s*{')
    if clientStart then
        local clientBrace = block:find('{', clientStart, true)
        local clientEnd = clientBrace and findClosingBrace(block, clientBrace)

        if clientBrace and clientEnd then
            local clientBlock = block:sub(clientBrace + 1, clientEnd - 1)
            local newClientBlock, count = clientBlock:gsub('image%s*=%s*[\'\"][^\'\"]+%.png[\'\"],?', 'image = ' .. luaString(image) .. ',', 1)
            if count == 0 then
                newClientBlock = ('\n            image = %s,'):format(luaString(image)) .. newClientBlock
            end
            return block:sub(1, clientBrace) .. newClientBlock .. block:sub(clientEnd)
        end
    end

    local open = block:find('{', 1, true)
    local close = open and findClosingBrace(block, open)
    if not close then return block end

    local insert = ('\n        client = {\n            image = %s,\n        },'):format(luaString(image))
    return block:sub(1, close - 1) .. insert .. block:sub(close)
end

local function patchItemEntryBlock(block, payload)
    local label = tostring(payload.label or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if label == '' or #label > 96 then return nil, 'Item label is required.' end

    local weight = tonumber(payload.weight) or 0
    if weight < 0 then weight = 0 end
    weight = math.floor(weight)

    local description = tostring(payload.description or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if #description > 240 then description = description:sub(1, 240) end

    local image = cleanImageName(payload.image or '')
    if not payload.image or payload.image == '' then image = nil end

    block = upsertLuaField(block, 'label', luaString(label))
    block = upsertLuaField(block, 'weight', tostring(weight))
    block = upsertLuaField(block, 'stack', payload.stack == false and 'false' or 'true')
    block = upsertLuaField(block, 'close', payload.close == false and 'false' or 'true')

    if payload.consume == 0 or payload.consume == '0' then
        block = upsertLuaField(block, 'consume', '0')
    else
        block = removeLuaField(block, 'consume')
    end

    if description ~= '' then
        block = upsertLuaField(block, 'description', luaString(description))
    else
        block = removeLuaField(block, 'description')
    end

    block = upsertClientImage(block, image)

    return block
end

local function updateItemEntry(payload)
    local itemName = cleanConfigKey(payload and payload.name, false)
    if not itemName then return nil, 'Invalid item name.' end

    local path = 'data/items.lua'
    local content = readFile(path)
    if not content then return nil, 'missing_items_file' end

    local startPos, _, closePos = findItemEntryBlock(content, itemName)
    if not startPos then return nil, ('Item %s was not found in data/items.lua.'):format(itemName) end

    local oldBlock = content:sub(startPos, closePos)
    local newBlock, err = patchItemEntryBlock(oldBlock, payload)
    if not newBlock then return nil, err end

    local newContent = content:sub(1, startPos - 1) .. newBlock .. content:sub(closePos + 1)
    if #newContent > maxConfigBytes then return nil, ('File is too large. Max %s KB.'):format(math.floor(maxConfigBytes / 1024)) end

    local ok, backup = writeWithBackup(path, content, newContent)
    if not ok then return nil, backup end

    collectImagesFromText(newContent)
    saveRegistry()

    return { ok = true, name = itemName, path = path, backup = backup, message = ('Updated item %s. Restart ox_inventory to apply it.'):format(itemName) }
end


local function sanitizeShopKey(value)
    if type(value) ~= 'string' then return nil end
    value = value:gsub('[^%w_]', '')
    if value == '' or #value > 96 then return nil end
    return value
end

local function buildShopItemEntry(payload)
    local item = cleanConfigKey(payload.item, true)
    if not item then return nil, 'Invalid item name. Use letters, numbers, _ or - only.' end

    local price = tonumber(payload.price) or 0
    if price < 0 then price = 0 end
    price = math.floor(price)

    local grade = nil
    if payload.grade ~= nil and payload.grade ~= '' then
        grade = tonumber(payload.grade)
        if grade == nil or grade < 0 then return nil, 'Grade must be blank or a positive number.' end
        grade = math.floor(grade)
    end

    local registered = payload.registered == true
    local serial = tostring(payload.serial or ''):gsub('[^%w_%-]', ''):upper()
    if #serial > 24 then serial = serial:sub(1, 24) end

    local parts = { ('name = %s'):format(luaString(item)) }

    if price > 0 then parts[#parts + 1] = ('price = %d'):format(price) end
    if grade ~= nil then parts[#parts + 1] = ('grade = %d'):format(grade) end
    if registered or serial ~= '' then
        local metadata = { 'registered = true' }
        if serial ~= '' then metadata[#metadata + 1] = ('serial = %s'):format(luaString(serial)) end
        parts[#parts + 1] = ('metadata = { %s }'):format(table.concat(metadata, ', '))
    end

    return item, ('            { %s },'):format(table.concat(parts, ', '))
end

local function addEntryToShopInventory(text, shop, itemLine, itemName)
    local shopPattern = '\n%s*' .. shop .. '%s*=%s*{'
    local shopStart = text:find(shopPattern)

    if not shopStart then
        shopStart = text:find('^%s*' .. shop .. '%s*=%s*{')
    end

    if not shopStart then return nil, 'Shop was not found in data/shops.lua.' end

    local shopBrace = text:find('{', shopStart, true)
    if not shopBrace then return nil, 'Shop block is malformed.' end

    local shopEnd = findClosingBrace(text, shopBrace)
    if not shopEnd then return nil, 'Could not find the end of this shop block.' end

    local invStart = text:find('inventory%s*=%s*{', shopBrace)
    if not invStart or invStart > shopEnd then return nil, 'This shop has no inventory = { } block.' end

    local invBrace = text:find('{', invStart, true)
    local invEnd = invBrace and findClosingBrace(text, invBrace)
    if not invEnd or invEnd > shopEnd then return nil, 'Could not find the end of this shop inventory block.' end

    local invBlock = text:sub(invBrace, invEnd)
    for found in invBlock:gmatch("name%s*=%s*['\"]([^'\"]+)['\"]") do
        if found == itemName then return nil, 'That item is already in this shop.' end
    end

    text, invEnd = ensureCommaBeforeInsert(text, invEnd)

    return text:sub(1, invEnd - 1) .. '\n' .. itemLine .. text:sub(invEnd)
end



-- GTA V Leaflet map support for moving ox_inventory shop blips/locations.
mapConfig = {
    tileUrls = {
        atlas = 'https://cdn.jsdelivr.net/gh/Trusted-Studios/mapStyles@main/styleAtlas/{z}/{x}/{y}.jpg',
        grid = 'https://cdn.jsdelivr.net/gh/Trusted-Studios/mapStyles@main/styleGrid/{z}/{x}/{y}.png',
        satellite = 'https://cdn.jsdelivr.net/gh/Trusted-Studios/mapStyles@main/styleSatelite/{z}/{x}/{y}.jpg',
    },
    bounds = {
        minX = -4200.0,
        maxX = 4500.0,
        minY = -4300.0,
        maxY = 8200.0,
    },
    crs = {
        centerX = 117.3,
        centerY = 172.8,
        scaleX = 0.02072,
        scaleY = 0.0205,
    }
}

local function fmtCoord(value)
    value = tonumber(value) or 0.0
    return ('%.2f'):format(value)
end

local function findShopBlock(text, shop)
    shop = sanitizeShopKey(shop)
    if not shop or type(text) ~= 'string' then return nil end

    local shopStart = text:find('\n%s*' .. shop .. '%s*=%s*{')
    if not shopStart then
        shopStart = text:find('^%s*' .. shop .. '%s*=%s*{')
    end
    if not shopStart then return nil end

    local shopBrace = text:find('{', shopStart, true)
    if not shopBrace then return nil end

    local shopEnd = findClosingBrace(text, shopBrace)
    if not shopEnd then return nil end

    return shopStart, shopBrace, shopEnd
end

local function findNamedBlock(text, startPos, endPos, name)
    if not startPos or not endPos then return nil end

    local blockStart = text:find(name .. '%s*=%s*{', startPos)
    if not blockStart or blockStart > endPos then return nil end

    local brace = text:find('{', blockStart, true)
    if not brace or brace > endPos then return nil end

    local close = findClosingBrace(text, brace)
    if not close or close > endPos then return nil end

    return blockStart, brace, close
end

local function parseVec3s(block, locOnly)
    local list, n = {}, 0
    if type(block) ~= 'string' then return list end

    local pattern = locOnly
        and 'loc%s*=%s*vec3%s*%(%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*%)'
        or 'vec3%s*%(%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*%)'

    local pos = 1
    while true do
        local a, b, x, y, z = block:find(pattern, pos)
        if not a then break end

        n = n + 1
        list[n] = {
            x = tonumber(x) or 0.0,
            y = tonumber(y) or 0.0,
            z = tonumber(z) or 0.0,
            a = a,
            b = b,
        }

        pos = b + 1
    end

    return list
end

parseShopLocations = function(text)
    local locations, n = {}, 0
    if type(text) ~= 'string' then return locations end

    local shops = parseShopEntries(text)

    for i = 1, #shops do
        local shop = shops[i]
        local shopStart, _, shopEnd = findShopBlock(text, shop.name)

        if shopStart and shopEnd then
            local shopBlock = text:sub(shopStart, shopEnd)
            local label = quotedValue(shopBlock, 'name') or shop.label or shop.name
            local blipId = tonumber(shopBlock:match('id%s*=%s*(%d+)')) or 59
            local blipColour = tonumber(shopBlock:match('colour%s*=%s*(%d+)')) or 69
            local _, locBrace, locEnd = findNamedBlock(text, shopStart, shopEnd, 'locations')
            local _, targetBrace, targetEnd = findNamedBlock(text, shopStart, shopEnd, 'targets')
            local targetVecs = {}

            if targetBrace and targetEnd then
                targetVecs = parseVec3s(text:sub(targetBrace + 1, targetEnd - 1), true)
            end

            if locBrace and locEnd then
                local vecs = parseVec3s(text:sub(locBrace + 1, locEnd - 1), false)

                for index = 1, #vecs do
                    local vec = vecs[index]
                    n = n + 1
                    locations[n] = {
                        id = ('%s:%s'):format(shop.name, index),
                        shop = shop.name,
                        shopLabel = label,
                        index = index,
                        x = vec.x,
                        y = vec.y,
                        z = vec.z,
                        blipId = blipId,
                        blipColour = blipColour,
                        hasTarget = targetVecs[index] ~= nil,
                    }
                end
            end
        end
    end

    table.sort(locations, function(a, b)
        if a.shop == b.shop then return a.index < b.index end
        return a.shop < b.shop
    end)

    return locations
end

local function replaceNthVec3(text, startPos, endPos, index, x, y, z, locOnly)
    local block = text:sub(startPos, endPos)
    local pattern = locOnly
        and 'loc%s*=%s*vec3%s*%(%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*%)'
        or 'vec3%s*%(%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*%)'

    local count = 0
    local pos = 1

    while true do
        local a, b, oldX, oldY, oldZ = block:find(pattern, pos)
        if not a then return nil, 'location_index_not_found' end

        count = count + 1
        if count == index then
            local newVec = locOnly
                and ('loc = vec3(%s, %s, %s)'):format(fmtCoord(x), fmtCoord(y), fmtCoord(z or oldZ))
                or ('vec3(%s, %s, %s)'):format(fmtCoord(x), fmtCoord(y), fmtCoord(z or oldZ))
            local absA = startPos + a - 1
            local absB = startPos + b - 1
            return text:sub(1, absA - 1) .. newVec .. text:sub(absB + 1)
        end

        pos = b + 1
    end
end

local function addLocationToShop(text, shop, x, y, z)
    local shopStart, _, shopEnd = findShopBlock(text, shop)
    if not shopStart then return nil, 'Shop was not found in data/shops.lua.' end

    local _, locBrace, locEnd = findNamedBlock(text, shopStart, shopEnd, 'locations')
    if not locBrace or not locEnd then
        return nil, 'This shop has no locations = { } block. Add one in the raw editor first.'
    end

    text, locEnd = ensureCommaBeforeInsert(text, locEnd)
    local line = ('\n\t\t\tvec3(%s, %s, %s),'):format(fmtCoord(x), fmtCoord(y), fmtCoord(z))
    return text:sub(1, locEnd - 1) .. line .. text:sub(locEnd)
end


local function triggerRestartHelper(requestSource)
    local helper = restartHelperResource or 'ox_inventory_restart_helper'
    local state = GetResourceState(helper)

    if state == 'missing' then
        print(('[ox_inventory] oxconfig restart helper resource "%s" is missing. Falling back to ExecuteCommand restart.'):format(helper))
        print('[ox_inventory] For reliable UI restarts, extract/ensure ox_inventory_restart_helper or add: add_ace resource.ox_inventory command.restart allow')
        ExecuteCommand(('restart %s'):format(resource))
        return false
    end

    if state ~= 'started' then
        local ok, result = pcall(StartResource, helper)
        print(('[ox_inventory] starting restart helper %s ok=%s result=%s state=%s'):format(helper, tostring(ok), tostring(result), GetResourceState(helper)))
    end

    SetTimeout(350, function()
        if GetResourceState(helper) == 'started' then
            TriggerEvent('ox_inventory_restart_helper:restart', resource, requestSource or 0)
        else
            print(('[ox_inventory] restart helper %s failed to start. Falling back to ExecuteCommand restart.'):format(helper))
            ExecuteCommand(('restart %s'):format(resource))
        end
    end)

    return true
end

local function performOxConfigRestart(source, reason)
    if not isAdmin(source) then
        if source and source > 0 then notify(source, 'You do not have permission to restart ox_inventory.', 'error') end
        return false, 'not_allowed'
    end

    if restartQueued then return true end
    restartQueued = true

    print(('[ox_inventory] oxconfig HARD restart queued by %s (%s). Closing UIs before restart.'):format(source or 0, reason or 'unknown'))

    TriggerClientEvent('ox_inventory:oxconfig:forceClose', -1)
    TriggerClientEvent('ox_inventory:closeInventory', -1, true)
    TriggerClientEvent('ox_inventory:closeInventory', -1)

    if source and source > 0 then
        notify(source, 'Closing UIs and hard-restarting ox_inventory...', 'warning')
    end

    -- Do the actual restart from a separate helper resource. A resource trying
    -- to stop/start itself is unreliable and command.restart can be ACE-blocked.
    SetTimeout(950, function()
        triggerRestartHelper(source or 0)
    end)

    return true
end

RegisterNetEvent('ox_inventory:oxconfig:restart', function()
    performOxConfigRestart(source, 'nui-event')
end)

RegisterCommand('oxconfig', function(source)
    if source == 0 then
        print('[ox_inventory] /oxconfig is an in-game admin UI command.')
        return
    end

    if not isAdmin(source) then
        notify(source, 'You do not have permission to use /oxconfig.', 'error')
        return
    end

    TriggerClientEvent('ox_inventory:oxconfig:open', source)
end, false)

RegisterCommand('oxconfigrestart', function(source)
    performOxConfigRestart(source, 'command')
end, false)

lib.callback.register('ox_inventory:oxconfig:getDashboard', function(source)
    if not isAdmin(source) then return false, 'not_allowed' end
    return dashboard()
end)


lib.callback.register('ox_inventory:oxconfig:saveSettings', function(source, payload)
    if not isAdmin(source) then return false, 'not_allowed' end

    local settings, err = cleanSettingsPayload(payload)
    if not settings then return false, err end

    local ok, saveErr = saveSettings(settings)
    if not ok then return false, saveErr end

    return {
        ok = true,
        settings = settings,
        path = settingsPath,
        message = settings.nativeWeaponWheel and 'Saved GTA native weapon wheel mode. Restart ox_inventory to apply it.' or 'Settings saved. Restart ox_inventory to apply all changes.'
    }
end)

lib.callback.register('ox_inventory:oxconfig:readFile', function(source, path)
    if not isAdmin(source) then return false, 'not_allowed' end

    path = safeDataPath(path)
    if not path then return false, 'invalid_path' end

    local content = readFile(path)
    if not content then return false, 'missing_file' end

    return {
        path = path,
        content = content,
        bytes = #content,
    }
end)

lib.callback.register('ox_inventory:oxconfig:saveFile', function(source, path, content)
    if not isAdmin(source) then return false, 'not_allowed' end

    path = safeDataPath(path)
    if not path then return false, 'invalid_path' end
    if type(content) ~= 'string' then return false, 'invalid_content' end
    if #content > maxConfigBytes then return false, ('File is too large. Max %s KB.'):format(math.floor(maxConfigBytes / 1024)) end

    local old = readFile(path)
    if not old then return false, 'missing_file' end

    local backupPath = ('%s.bak.%s'):format(path, os.time())
    writeFile(backupPath, old)

    local ok = writeFile(path, content)
    if not ok then return false, 'save_failed' end

    collectImagesFromText(content)
    saveRegistry()

    return {
        ok = true,
        path = path,
        backup = backupPath,
        message = 'Saved. Restart ox_inventory to apply Lua data changes.'
    }
end)

lib.callback.register('ox_inventory:oxconfig:uploadImage', function(source, name, dataUrl)
    if not isAdmin(source) then return false, 'not_allowed' end

    local path, clean = imagePath(name)
    if not path then return false, 'invalid_filename' end
    if type(dataUrl) ~= 'string' then return false, 'invalid_image' end

    local encoded = dataUrl:match('^data:image/png;base64,(.+)$') or dataUrl:match('^data:application/octet%-stream;base64,(.+)$') or dataUrl
    encoded = encoded:gsub('%s+', '')

    local decoded = decodeBase64(encoded)
    if not decoded or #decoded == 0 then return false, 'invalid_png_data' end
    if #decoded > maxImageBytes then return false, ('Image is too large. Max %s KB.'):format(math.floor(maxImageBytes / 1024)) end

    -- PNG signature: 89 50 4E 47 0D 0A 1A 0A
    if decoded:byte(1) ~= 137 or decoded:byte(2) ~= 80 or decoded:byte(3) ~= 78 or decoded:byte(4) ~= 71 then
        return false, 'Only PNG files are allowed.'
    end

    local old = readFile(path)
    if old then
        writeFile(('%s.bak.%s'):format(path, os.time()), old)
    end

    local ok = writeFile(path, decoded)
    if not ok then return false, 'save_failed' end

    addImageName(clean)
    saveRegistry()

    return {
        ok = true,
        name = clean,
        path = path,
        url = ('nui://%s/web/images/%s'):format(resource, clean),
        size = #decoded,
        message = old and 'Image replaced.' or 'Image uploaded.'
    }
end)

lib.callback.register('ox_inventory:oxconfig:deleteImage', function(source, name)
    if not isAdmin(source) then return false, 'not_allowed' end

    local path, clean = imagePath(name)
    if not path then return false, 'invalid_filename' end

    local fullPath = GetResourcePath(resource)
    if fullPath then
        fullPath = ('%s/%s'):format(fullPath, path)
        pcall(os.remove, fullPath)
    end

    imageSet[clean] = nil
    saveRegistry()

    return { ok = true, name = clean, message = 'Image removed from the oxconfig registry. Existing config references must be updated manually.' }
end)



lib.callback.register('ox_inventory:oxconfig:createItem', function(source, payload)
    if not isAdmin(source) then return false, 'not_allowed' end
    if type(payload) ~= 'table' then return false, 'invalid_payload' end

    local path = 'data/items.lua'
    local content = readFile(path)
    if not content then return false, 'missing_items_file' end

    local name, entryOrErr = buildItemEntry(payload)
    if not name then return false, entryOrErr end

    if hasBracketEntry(content, name) then
        return false, ('Item %s already exists. Use the raw editor to modify it.'):format(name)
    end

    local insertPos = finalReturnBracePos(content)
    if not insertPos then return false, 'Could not find the closing } in data/items.lua.' end

    content, insertPos = ensureCommaBeforeInsert(content, insertPos)

    local newContent = content:sub(1, insertPos - 1) .. '\n\n' .. entryOrErr .. '\n' .. content:sub(insertPos)
    if #newContent > maxConfigBytes then return false, ('File is too large. Max %s KB.'):format(math.floor(maxConfigBytes / 1024)) end

    local ok, backup = writeWithBackup(path, content, newContent)
    if not ok then return false, backup end

    collectImagesFromText(newContent)
    saveRegistry()

    return { ok = true, name = name, path = path, backup = backup, message = ('Created item %s. Restart ox_inventory to apply it.'):format(name) }
end)

lib.callback.register('ox_inventory:oxconfig:updateItem', function(source, payload)
    if not isAdmin(source) then return false, 'not_allowed' end
    if type(payload) ~= 'table' then return false, 'invalid_payload' end

    local result, err = updateItemEntry(payload)
    if not result then return false, err end

    return result
end)


lib.callback.register('ox_inventory:oxconfig:addShopItem', function(source, payload)
    if not isAdmin(source) then return false, 'not_allowed' end
    if type(payload) ~= 'table' then return false, 'invalid_payload' end

    local shop = sanitizeShopKey(payload.shop)
    if not shop then return false, 'Invalid shop key.' end

    local itemName, itemLineOrErr = buildShopItemEntry(payload)
    if not itemName then return false, itemLineOrErr end

    local path = 'data/shops.lua'
    local content = readFile(path)
    if not content then return false, 'missing_shops_file' end

    local newContent, err = addEntryToShopInventory(content, shop, itemLineOrErr, itemName)
    if not newContent then return false, err end
    if #newContent > maxConfigBytes then return false, ('File is too large. Max %s KB.'):format(math.floor(maxConfigBytes / 1024)) end

    local ok, backup = writeWithBackup(path, content, newContent)
    if not ok then return false, backup end

    return { ok = true, shop = shop, item = itemName, path = path, backup = backup, message = ('Added %s to %s. Restart ox_inventory to apply it.'):format(itemName, shop) }
end)



lib.callback.register('ox_inventory:oxconfig:moveShopLocation', function(source, payload)
    if not isAdmin(source) then return false, 'not_allowed' end
    if type(payload) ~= 'table' then return false, 'invalid_payload' end

    local shop = sanitizeShopKey(payload.shop)
    local index = tonumber(payload.index)
    local x = tonumber(payload.x)
    local y = tonumber(payload.y)
    local z = tonumber(payload.z)

    if not shop then return false, 'Invalid shop key.' end
    if not index or index < 1 then return false, 'Invalid location index.' end
    if not x or not y or not z then return false, 'Invalid coordinates.' end

    index = math.floor(index)

    local path = 'data/shops.lua'
    local content = readFile(path)
    if not content then return false, 'missing_shops_file' end

    local shopStart, _, shopEnd = findShopBlock(content, shop)
    if not shopStart then return false, 'Shop was not found in data/shops.lua.' end

    local _, locBrace, locEnd = findNamedBlock(content, shopStart, shopEnd, 'locations')
    if not locBrace or not locEnd then return false, 'This shop has no locations = { } block.' end

    local newContent, err = replaceNthVec3(content, locBrace + 1, locEnd - 1, index, x, y, z, false)
    if not newContent then return false, err end

    if payload.updateTarget ~= false then
        local newShopStart, _, newShopEnd = findShopBlock(newContent, shop)
        local _, targetBrace, targetEnd = findNamedBlock(newContent, newShopStart, newShopEnd, 'targets')
        if targetBrace and targetEnd then
            local withTarget = replaceNthVec3(newContent, targetBrace + 1, targetEnd - 1, index, x, y, z, true)
            if withTarget then newContent = withTarget end
        end
    end

    if #newContent > maxConfigBytes then return false, ('File is too large. Max %s KB.'):format(math.floor(maxConfigBytes / 1024)) end

    local ok, backup = writeWithBackup(path, content, newContent)
    if not ok then return false, backup end

    return {
        ok = true,
        id = ('%s:%s'):format(shop, index),
        shop = shop,
        index = index,
        backup = backup,
        message = ('Moved %s location #%s. Restart ox_inventory to apply it.'):format(shop, index)
    }
end)

lib.callback.register('ox_inventory:oxconfig:addShopLocation', function(source, payload)
    if not isAdmin(source) then return false, 'not_allowed' end
    if type(payload) ~= 'table' then return false, 'invalid_payload' end

    local shop = sanitizeShopKey(payload.shop)
    local x = tonumber(payload.x)
    local y = tonumber(payload.y)
    local z = tonumber(payload.z)

    if not shop then return false, 'Invalid shop key.' end
    if not x or not y or not z then return false, 'Invalid coordinates.' end

    local path = 'data/shops.lua'
    local content = readFile(path)
    if not content then return false, 'missing_shops_file' end

    local newContent, err = addLocationToShop(content, shop, x, y, z)
    if not newContent then return false, err end
    if #newContent > maxConfigBytes then return false, ('File is too large. Max %s KB.'):format(math.floor(maxConfigBytes / 1024)) end

    local ok, backup = writeWithBackup(path, content, newContent)
    if not ok then return false, backup end

    return {
        ok = true,
        shop = shop,
        backup = backup,
        message = ('Added a new location to %s. Restart ox_inventory to apply it.'):format(shop)
    }
end)

lib.callback.register('ox_inventory:oxconfig:listImages', function(source)
    if not isAdmin(source) then return false, 'not_allowed' end
    return listImages()
end)

lib.callback.register('ox_inventory:oxconfig:restart', function(source)
    local ok, err = performOxConfigRestart(source, 'callback')
    if not ok then return false, err end
    return { ok = true, message = 'Restart queued.' }
end)
