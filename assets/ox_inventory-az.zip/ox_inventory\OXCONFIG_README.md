# ox_inventory Admin Config UI

This build adds an in-game admin command:

```txt
/oxconfig
```

It opens a Discord-style grey / blue admin panel for trusted admins to manage ox_inventory without needing to know Lua.

## What the UI can do

- View all parsed item names from `data/items.lua`
- Create a new item using a guided form
- View all parsed weapon names from `data/weapons.lua`
- View parsed shop names from `data/shops.lua`
- Use the GTA V Leaflet shop map to view and drag shop blips/locations
- Add an item or weapon to a shop/armory using a guided form
- Add optional price, grade lock, and registered weapon serial metadata
- Edit whitelisted raw Lua config files when a developer needs advanced control
- Upload / replace / delete PNG files under `web/images/*.png`
- Copy current player `vec3` and `vec4` coordinates for shop locations / targets
- Restart `ox_inventory` from the UI after saving

## Staff workflow

1. Open `/oxconfig`.
2. Upload the PNG image under the Images tab if the item needs a custom icon.
3. Go to Items and use **Create item without writing Lua**.
4. Go to Shops and use **Add item to shop without touching code**.
5. Restart `ox_inventory` from the top bar.

The raw Lua editor is still available, but the guided cards should be used first for normal staff/admin changes.

## Permissions

The menu checks these permissions:

- ACE: `ox_inventory.oxconfig`
- ACE: `command.oxconfig`
- ACE: `command.oxconfigrestart`
- ACE: `command`
- ACE: `admin`
- QBCore `god` / `admin`
- QBX admin-like permissions when available

Recommended server.cfg:

```cfg
add_ace group.admin ox_inventory.oxconfig allow
add_ace group.admin command.oxconfig allow
add_ace group.admin command.oxconfigrestart allow
```

Optional limits:

```cfg
setr inventory:oxconfig_max_config_kb 2048
setr inventory:oxconfig_max_image_kb 2048
setr inventory:oxconfig_ace ox_inventory.oxconfig
```

## Backend safety

The editor is intentionally whitelisted. It cannot write random server files. It only writes:

```txt
data/*.lua
web/images/*.png
```

Every Lua data save and guided write creates a backup file beside the original, such as:

```txt
data/items.lua.bak.1712345678
data/shops.lua.bak.1712345678
```

The no-code helper callbacks are server-side and validate names, paths, PNG uploads, duplicate shop entries, file size limits, and admin permissions before writing anything.

After editing Lua data files, restart `ox_inventory` to apply changes.


## GTA V Leaflet shop map

The Live Map tab uses the same GTA V/FiveM coordinate approach used in the prior Leaflet map scripts:

- Normal map: `styleAtlas`
- Grid map: `styleGrid`
- SAT map: `styleSatelite`
- GTA bounds: X `-4200` to `4500`, Y `-4300` to `8200`
- CRS transform: center `117.3, 172.8`, scale `0.02072, 0.0205`

Drag a marker or manually edit X/Y/Z. Saving writes back to `data/shops.lua`, creates a backup, and can also update the matching `targets[index].loc` entry when it exists.

Remote GTA tile URLs are used for the Leaflet view. If CEF cannot reach the tile CDN, the UI falls back to a local coordinate grid so markers can still be moved.


## Settings Home / GTA Native Weapon Wheel Mode

This build adds a **Settings Home** tab to `/oxconfig`.

- Saves basic settings to `oxconfig_settings.json` inside the resource.
- Existing `server.cfg` convars still work until Settings Home is saved.
- After saving settings, restart `ox_inventory` from the UI or console.
- The **Use GTA Native Weapons** preset enables the default GTA weapon wheel and disables ox weapon item handling.

Native weapon preset behavior:

```cfg
inventory:nativeweaponwheel 1
inventory:disableweaponitems 1
inventory:disableweapons 1
inventory:weaponmismatch 0
inventory:suppresspickups 0
```

When enabled, `data/weapons.lua` weapon/ammo/component/tint entries are skipped as ox items, ox weapon equip/hotkeys are disabled, the default GTA weapon wheel is allowed, and ox disarm will not remove weapons granted by GTA natives or another weapon resource.


## Az-Framework + GTA Native Weapon Wheel

This build supports `setr inventory:framework "az"` and `setr inventory:framework "auto"`.

Recommended Az-Framework native weapon setup:

```cfg
ensure oxmysql
ensure ox_lib
ensure Az-Framework

setr inventory:framework "az"
setr inventory:accounts ["money"]
setr inventory:azframeworkmoney 1

# GTA/native weapons instead of ox weapon items.
setr inventory:nativeweaponwheel 1
setr inventory:weaponwheel 1
setr inventory:disableweaponitems 1
setr inventory:disableweapons 1
setr inventory:weaponmismatch false
setr inventory:suppresspickups 0

ensure ox_inventory
```

Az player inventories are stored in the `ox_inventory` table using the full Az bridge identifier, for example `az:<discordid>:<charid>`, so duplicate `charid` values do not overwrite each other.


## Az-Framework Debug Mode

This build includes `config.lua` with `Config.Debug = true` by default. While enabled it prints detailed logs for:

- framework detection
- Az-Framework export calls
- character snapshot loading
- inventory creation
- `ox_inventory:setPlayerInventory` delivery to the client
- F2/K/TAB keybind attempts
- NUI `uiLoaded`
- blocked inventory-open reasons

Use this while testing Az-Framework. Once fixed, set:

```lua
Config.Debug = false
Config.DebugAz = false
Config.DebugVerbose = false
Config.DebugNotify = false
```

In-game/F8 debug command:

```txt
/oxinvdebug
```

That command prints the client state, sends it to the server, requests the Az snapshot again, and forces an ox inventory load retry.

## 2026-05-24 Live Map / Restart Hotfix

- `/oxconfig` restart now closes oxconfig and inventory UIs first, returns the NUI callback immediately, then restarts `ox_inventory` after a short delay.
- Live Map selection no longer destroys/recreates the whole Leaflet map when clicking a shop location.
- Clicking a shop location now pans/zooms to that marker instead of resetting to the full-map starting view.
- Map style switching now swaps the tile layer without rerendering the whole UI.
- Shop markers were redesigned as cleaner GTA-style pins with centered labels.
- Tile loading was tuned to reduce CEF/Leaflet lag.

## Reliable oxconfig resource restart

The Restart ox_inventory button now uses a tiny helper resource so ox_inventory is stopped and started from outside itself. This avoids the common FiveM issue where a resource can close its own NUI but cannot reliably restart itself.

Install both folders from the zip:

```cfg
ensure ox_inventory_restart_helper
ensure ox_inventory
```

The helper only accepts restart requests from the `ox_inventory` resource. If you choose not to use the helper, you must allow the resource restart command instead:

```cfg
add_ace resource.ox_inventory command.restart allow
```

## Item card editor

The Items tab now shows image cards like the Images tab. Click an item card to edit its basic fields: label, weight, image, description, stack, close, and consume behavior. Advanced custom Lua fields remain editable in the raw Lua editor below the card editor.
