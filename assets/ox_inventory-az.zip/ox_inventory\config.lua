--[[
    ox_inventory Az-Framework Debug Config
    Set Config.Debug = true while testing Az-Framework inventory loading.
    Turn it back to false on live once the bridge is confirmed working.
]]

Config = Config or {}

-- Master debug switch. This prints detailed client/server logs for inventory loading, keybind opens, NUI loading, Az snapshots, and money sync.
Config.Debug = true

-- Az-Framework bridge debug. Keep true while testing Az inventory loading.
Config.DebugAz = true

-- Extra noisy logs for repeated retry/export checks.
Config.DebugVerbose = true

-- Shows a small ox_lib notify when the inventory open is blocked, so it is not silent in-game.
Config.DebugNotify = true

-- Retry Az inventory load if the character snapshot is not ready yet after spawn/character select.
Config.AzRetryLoads = true
Config.AzRetryAttempts = 20
Config.AzRetryDelayMs = 1500

-- Resource name override in case the framework folder is renamed.
Config.AzResource = 'Az-Framework'
