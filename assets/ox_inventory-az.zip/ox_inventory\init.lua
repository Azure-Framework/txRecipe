-- oxconfig_settings.json lets trusted admins manage the most common ox_inventory
-- convars from /oxconfig without editing server.cfg. Server.cfg convars still work;
-- this file only overrides values that are present in the JSON and enabled=true.
local oxconfig_settings = {}

local function loadOxConfigSettings()
    local raw = LoadResourceFile(GetCurrentResourceName(), 'oxconfig_settings.json')
    if not raw or raw == '' then return {} end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= 'table' or decoded.enabled == false then return {} end

    return decoded
end

oxconfig_settings = loadOxConfigSettings()

local function oxSetting(key, fallback)
    local value = oxconfig_settings[key]
    if value == nil then return fallback end
    return value
end

local function oxBool(key, fallback)
    local value = oxSetting(key, nil)
    if value == nil then return fallback end
    if type(value) == 'boolean' then return value end
    if type(value) == 'number' then return value ~= 0 end
    if type(value) == 'string' then
        value = value:lower()
        return value == '1' or value == 'true' or value == 'yes' or value == 'on'
    end
    return fallback
end

local function oxInt(key, fallback)
    local value = tonumber(oxSetting(key, fallback))
    if value == nil then return fallback end
    return math.floor(value)
end

local function oxString(key, fallback)
    local value = oxSetting(key, nil)
    if value == nil then return fallback end
    return tostring(value)
end

local function oxList(key, convar, fallbackJson)
    local value = oxSetting(key, nil)
    if type(value) == 'table' then return value end
    if type(value) == 'string' and value ~= '' then
        local ok, decoded = pcall(json.decode, value)
        if ok and type(decoded) == 'table' then return decoded end
    end

    local ok, decoded = pcall(json.decode, GetConvar(convar, fallbackJson))
    if ok and type(decoded) == 'table' then return decoded end

    return json.decode(fallbackJson)
end

local function oxConfigBool(key, fallback)
    Config = Config or {}
    local value = Config[key]
    if value == nil then return fallback end
    if type(value) == 'boolean' then return value end
    if type(value) == 'number' then return value ~= 0 end
    if type(value) == 'string' then
        value = value:lower()
        return value == '1' or value == 'true' or value == 'yes' or value == 'on'
    end
    return fallback
end

local function oxConfigInt(key, fallback)
    Config = Config or {}
    local value = tonumber(Config[key])
    if value == nil then return fallback end
    return math.floor(value)
end

local function oxConfigString(key, fallback)
    Config = Config or {}
    local value = Config[key]
    if value == nil or value == '' then return fallback end
    return tostring(value)
end

local function convarBoolAny(keys, fallback)
    if type(keys) ~= 'table' then keys = { keys } end

    for i = 1, #keys do
        local raw = GetConvar(keys[i], '')
        if raw ~= '' then
            raw = raw:lower()
            return raw == '1' or raw == 'true' or raw == 'yes' or raw == 'on'
        end
    end

    return fallback
end

local function resolveFramework(value)
    value = tostring(value or 'esx'):lower()

    if value == 'azure' or value == 'az-framework' or value == 'azframework' then
        value = 'az'
    end

    if value ~= 'auto' then return value end

    local order = {
        { resource = 'Az-Framework', framework = 'az' },
        { resource = 'qbx_core', framework = 'qbx' },
        { resource = 'ox_core', framework = 'ox' },
        { resource = 'es_extended', framework = 'esx' },
        { resource = 'ND_Core', framework = 'nd' },
    }

    for i = 1, #order do
        local state = GetResourceState(order[i].resource)
        if state == 'started' or state == 'starting' then
            return order[i].framework
        end
    end

    return 'esx'
end

local function addDeferral(err)
    err = err:gsub("%^%d", "")

    AddEventHandler('playerConnecting', function(_, _, deferrals)
        deferrals.defer()
        deferrals.done(err)
    end)
end

-- Do not modify this file at all. This isn't a "config" file. You want to change
-- resource settings? Use convars like you were told in the documentation.
-- You did read the docs, right? Probably not, if you're here.
-- https://overextended.dev/ox_inventory#config

shared = {
    resource = GetCurrentResourceName(),
    framework = resolveFramework(oxString('framework', GetConvar('inventory:framework', 'esx'))),
    playerslots = oxInt('slots', GetConvarInt('inventory:slots', 50)),
    playerweight = oxInt('weight', GetConvarInt('inventory:weight', 30000)),
    target = oxBool('target', GetConvarInt('inventory:target', 0) == 1),
    police = oxList('police', 'inventory:police', '["police", "sheriff"]'),
    networkdumpsters = oxBool('networkdumpsters', GetConvarInt('inventory:networkdumpsters', 0) == 1),
    oxconfig = oxconfig_settings
}

shared.dropslots = oxInt('dropslots', GetConvarInt('inventory:dropslots', shared.playerslots))
shared.dropweight = oxInt('dropweight', GetConvarInt('inventory:dropweight', shared.playerweight))

shared.debug = oxConfigBool('Debug', convarBoolAny({ 'inventory:debug', 'inventory:azdebug' }, false))
shared.debugAz = oxConfigBool('DebugAz', shared.debug or GetConvarInt('inventory:azdebug', 0) == 1)
shared.debugVerbose = oxConfigBool('DebugVerbose', GetConvarInt('inventory:debugverbose', 0) == 1)
shared.debugNotify = oxConfigBool('DebugNotify', GetConvarInt('inventory:debugnotify', shared.debug and 1 or 0) == 1)
shared.azresource = oxConfigString('AzResource', GetConvar('inventory:azresource', 'Az-Framework'))
shared.azRetryLoads = oxConfigBool('AzRetryLoads', true)
shared.azRetryAttempts = oxConfigInt('AzRetryAttempts', GetConvarInt('inventory:azretryattempts', 20))
shared.azRetryDelayMs = oxConfigInt('AzRetryDelayMs', GetConvarInt('inventory:azretrydelay', 1500))


do
    if type(shared.police) == 'string' then
        shared.police = { shared.police }
    end

    local police = table.create(0, shared.police and #shared.police or 0)

    for i = 1, #shared.police do
        police[shared.police[i]] = 0
    end

    shared.police = police
end

if IsDuplicityVersion() then
    server = {
        bulkstashsave = oxBool('bulkstashsave', GetConvarInt('inventory:bulkstashsave', 1) == 1),
        loglevel = oxInt('loglevel', GetConvarInt('inventory:loglevel', 1)),
        randomprices = oxBool('randomprices', GetConvarInt('inventory:randomprices', 0) == 1),
        randomloot = oxBool('randomloot', GetConvarInt('inventory:randomloot', 1) == 1),
        evidencegrade = oxInt('evidencegrade', GetConvarInt('inventory:evidencegrade', 2)),
        trimplate = oxBool('trimplate', GetConvarInt('inventory:trimplate', 1) == 1),
        vehicleloot = oxList('vehicleloot', 'inventory:vehicleloot', [[
			[
				["sprunk", 1, 1],
				["water", 1, 1],
				["garbage", 1, 2, 50],
				["panties", 1, 1, 5],
				["money", 1, 50],
				["money", 200, 400, 5],
				["bandage", 1, 1]
			]
		]]),
        dumpsterloot = oxList('dumpsterloot', 'inventory:dumpsterloot', [[
			[
				["mustard", 1, 1],
				["garbage", 1, 3],
				["money", 1, 10],
				["burger", 1, 1]
			]
		]]),
        validhosts = oxList('validhosts', 'inventory:validhosts', [[
			{
                "r2.fivemanage.com": true,
                "i.fmfile.com": true
            }
		]]),
    }

    local accounts = oxList('accounts', 'inventory:accounts', '["money"]')
    server.accounts = table.create(0, #accounts)

    for i = 1, #accounts do
        server.accounts[accounts[i]] = 0
    end
else
    PlayerData = {}
    client = {
        autoreload = oxBool('autoreload', GetConvarInt('inventory:autoreload', 0) == 1),
        screenblur = oxBool('screenblur', GetConvarInt('inventory:screenblur', 1) == 1),
        keys = oxList('keys', 'inventory:keys', '["F2","K","TAB"]') or { 'F2', 'K', 'TAB' },
        enablekeys = oxList('enablekeys', 'inventory:enablekeys', '[249]'),
        aimedfiring = oxBool('aimedfiring', GetConvarInt('inventory:aimedfiring', 0) == 1),
        giveplayerlist = oxBool('giveplayerlist', GetConvarInt('inventory:giveplayerlist', 0) == 1),
        weaponanims = oxBool('weaponanims', GetConvarInt('inventory:weaponanims', 1) == 1),
        itemnotify = oxBool('itemnotify', GetConvarInt('inventory:itemnotify', 1) == 1),
        weaponnotify = oxBool('weaponnotify', GetConvarInt('inventory:weaponnotify', 1) == 1),
        imagepath = oxString('imagepath', GetConvar('inventory:imagepath', 'nui://ox_inventory/web/images')),
        dropprops = oxBool('dropprops', GetConvarInt('inventory:dropprops', 0) == 1),
        dropmodel = joaat(oxString('dropmodel', GetConvar('inventory:dropmodel', 'prop_med_bag_01b'))),
        weaponmismatch = oxBool('weaponmismatch', GetConvarInt('inventory:weaponmismatch', 1) == 1),
        ignoreweapons = oxList('ignoreweapons', 'inventory:ignoreweapons', '[]'),
        suppresspickups = oxBool('suppresspickups', GetConvarInt('inventory:suppresspickups', 1) == 1),
        nativeweaponwheel = oxBool('nativeWeaponWheel', convarBoolAny({ 'inventory:nativeweaponwheel', 'inventory:weaponwheel' }, false)),
        disableweaponitems = oxBool('disableWeaponItems', GetConvarInt('inventory:disableweaponitems', 0) == 1),
        disableweapons = oxBool('disableweapons', GetConvarInt('inventory:disableweapons', 0) == 1) or oxBool('nativeWeaponWheel', convarBoolAny({ 'inventory:nativeweaponwheel', 'inventory:weaponwheel' }, false)),
        disablesetupnotification = oxBool('disablesetupnotification', GetConvarInt('inventory:disablesetupnotification', 0) == 1),
        enablestealcommand = oxBool('enablestealcommand', GetConvarInt('inventory:enablestealcommand', 1) == 1),
    }

    local ignoreweapons = table.create(0, (client.ignoreweapons and #client.ignoreweapons or 0) + 3)

    for i = 1, #client.ignoreweapons do
        local weapon = client.ignoreweapons[i]
        ignoreweapons[tonumber(weapon) or joaat(weapon)] = true
    end

    ignoreweapons[`WEAPON_UNARMED`] = true
    ignoreweapons[`WEAPON_HANDCUFFS`] = true
    ignoreweapons[`WEAPON_GARBAGEBAG`] = true
    ignoreweapons[`OBJECT`] = true
    ignoreweapons[`WEAPON_HOSE`] = true

    client.ignoreweapons = ignoreweapons

    local fallbackmarker = {
        type = 0,
        colour = { 150, 150, 150 },
        scale = { 0.5, 0.5, 0.5 }
    }

    client.shopmarker = json.decode(GetConvar('inventory:shopmarker', [[
        {
            "type": 29,
            "colour": [30, 150, 30],
            "scale": [0.5, 0.5, 0.5]
        }
    ]])) or fallbackmarker

    client.evidencemarker = json.decode(GetConvar('inventory:evidencemarker', [[
        {
            "type": 2,
            "colour": [30, 30, 150],
            "scale": [0.3, 0.2, 0.15]
        }
    ]])) or fallbackmarker

    client.craftingmarker = json.decode(GetConvar('inventory:craftingmarker', [[
        {
            "type": 2,
            "colour": [150, 150, 30],
            "scale": [0.3, 0.2, 0.15]
        }
    ]])) or fallbackmarker

    client.dropmarker = json.decode(GetConvar('inventory:dropmarker', [[
        {
            "type": 2,
            "colour": [150, 30, 30],
            "scale": [0.3, 0.2, 0.15]
        }
    ]])) or fallbackmarker
end

function shared.print(...) print(string.strjoin(' ', ...)) end

function shared.debugLog(category, ...)
    if not shared.debug then return end

    local msg = string.strjoin(' ', ...)
    local side = IsDuplicityVersion() and 'server' or 'client'
    lib.print.info(('[debug:%s:%s] %s'):format(side, tostring(category or 'general'), msg))
end

function shared.info(...)
    lib.print.info(string.strjoin(' ', ...))
end

if shared.debug then
    shared.debugLog('startup', ('resource=%s framework=%s slots=%s weight=%s target=%s nativeWeaponWheel=%s disableWeapons=%s azResource=%s'):format(
        tostring(shared.resource), tostring(shared.framework), tostring(shared.playerslots), tostring(shared.playerweight), tostring(shared.target),
        tostring(client and client.nativeweaponwheel or 'server-side'), tostring(client and client.disableweapons or 'server-side'), tostring(shared.azresource)
    ))
end


---Throws a formatted type error.
---```lua
---error("expected %s to have type '%s' (received %s)")
---```
---@param variable string
---@param expected string
---@param received string
function TypeError(variable, expected, received)
    error(("expected %s to have type '%s' (received %s)"):format(variable, expected, received))
end

-- People like ignoring errors for some reason
local function spamError(err)
    shared.ready = false

    CreateThread(function()
        while true do
            Wait(10000)
            CreateThread(function()
                error(err, 0)
            end)
        end
    end)

    addDeferral(err)
    error(err, 0)
end

---@param name string
---@return table
---@deprecated
function data(name)
    if shared.server and shared.ready == nil then return {} end
    local file = ('data/%s.lua'):format(name)
    local datafile = LoadResourceFile(shared.resource, file)
    local path = ('@@%s/%s'):format(shared.resource, file)

    if not datafile then
        warn(('no datafile found at path %s'):format(path:gsub('@@', '')))
        return {}
    end

    local func, err = load(datafile, path)

    if not func or err then
        shared.ready = false
        ---@diagnostic disable-next-line: return-type-mismatch
        return spamError(err)
    end

    return func()
end

if not lib then
    return spamError('ox_inventory requires the ox_lib resource, refer to the documentation.')
end

local success, msg = lib.checkDependency('oxmysql', '2.7.3')

if success then
    success, msg = lib.checkDependency('ox_lib', '3.27.0')
end

if not success then
    return spamError(msg)
end

if not LoadResourceFile(shared.resource, 'web/build/index.html') then
    return spamError(
        'UI has not been built, refer to the documentation or download a release build.\n	^3https://overextended.dev/ox_inventory^0')
end

-- No we're not going to support qtarget any longer.
if shared.target and GetResourceState('ox_target') ~= 'started' then
    shared.target = false
    warn('ox_target is not loaded - it should start before ox_inventory')
end

if lib.context == 'server' then
    shared.ready = false
    return require 'server'
end

require 'client'
