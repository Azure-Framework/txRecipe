-- Client glue for the ox_inventory admin config UI.

local oxConfigOpen = false
local controlsLocked = false

local function notify(msg, notifyType)
    if lib and lib.notify then
        lib.notify({ type = notifyType or 'inform', description = msg })
    else
        print(('[oxconfig] %s'):format(msg))
    end
end

local function lockOxConfigInput()
    oxConfigOpen = true
    controlsLocked = true

    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)
    SetPlayerControl(PlayerId(), false, 0)
end

local function unlockOxConfigInput()
    oxConfigOpen = false
    controlsLocked = false

    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SetPlayerControl(PlayerId(), true, 0)
end

local function closeOxConfig()
    unlockOxConfigInput()
    SendNUIMessage({ action = 'oxconfig:close' })
end

CreateThread(function()
    local lastFocusRefresh = 0

    while true do
        if oxConfigOpen then
            Wait(0)

            DisableAllControlActions(0)
            DisableAllControlActions(1)
            DisableAllControlActions(2)

            DisableControlAction(0, 1, true) -- Look left/right
            DisableControlAction(0, 2, true) -- Look up/down
            DisableControlAction(0, 24, true) -- Attack
            DisableControlAction(0, 25, true) -- Aim
            DisableControlAction(0, 30, true) -- Move left/right
            DisableControlAction(0, 31, true) -- Move forward/back
            DisableControlAction(0, 32, true) -- W
            DisableControlAction(0, 33, true) -- S
            DisableControlAction(0, 34, true) -- A
            DisableControlAction(0, 35, true) -- D
            DisableControlAction(0, 37, true) -- Weapon wheel
            DisableControlAction(0, 44, true) -- Cover
            DisableControlAction(0, 45, true) -- Reload
            DisableControlAction(0, 68, true) -- Vehicle aim
            DisableControlAction(0, 69, true) -- Vehicle attack
            DisableControlAction(0, 70, true) -- Vehicle attack 2
            DisableControlAction(0, 75, true) -- Exit vehicle
            DisableControlAction(0, 85, true) -- Radio wheel
            DisableControlAction(0, 91, true) -- Passenger aim
            DisableControlAction(0, 92, true) -- Passenger attack
            DisableControlAction(0, 99, true) -- Vehicle select next weapon
            DisableControlAction(0, 106, true) -- Vehicle mouse control override
            DisableControlAction(0, 140, true) -- Melee light
            DisableControlAction(0, 141, true) -- Melee heavy
            DisableControlAction(0, 142, true) -- Melee alternate
            DisableControlAction(0, 199, true) -- Pause menu
            DisableControlAction(0, 200, true) -- Pause menu escape
            DisableControlAction(0, 245, true) -- Chat
            DisableControlAction(0, 257, true) -- Attack 2
            DisableControlAction(0, 263, true) -- Melee attack 1
            DisableControlAction(0, 264, true) -- Melee attack 2
            DisableControlAction(0, 322, true) -- ESC

            if GetGameTimer() - lastFocusRefresh > 750 then
                lastFocusRefresh = GetGameTimer()
                SetNuiFocus(true, true)
                SetNuiFocusKeepInput(false)
                SetPlayerControl(PlayerId(), false, 0)
            end

            if IsDisabledControlJustReleased(0, 322) or IsDisabledControlJustReleased(0, 200) then
                closeOxConfig()
            end
        elseif controlsLocked then
            unlockOxConfigInput()
            Wait(250)
        else
            Wait(250)
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SetPlayerControl(PlayerId(), true, 0)
end)

RegisterNetEvent('ox_inventory:oxconfig:notify', function(msg, notifyType)
    notify(msg, notifyType)
end)

RegisterNetEvent('ox_inventory:oxconfig:forceClose', function()
    closeOxConfig()
end)

RegisterNetEvent('ox_inventory:oxconfig:open', function()
    lockOxConfigInput()
    SendNUIMessage({ action = 'oxconfig:open' })
end)

RegisterNUICallback('oxConfigClose', function(_, cb)
    closeOxConfig()
    cb({ ok = true })
end)

RegisterNUICallback('oxConfigDashboard', function(_, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:getDashboard', false)
    cb(result or { ok = false, error = err or 'Unable to load oxconfig dashboard.' })
end)


RegisterNUICallback('oxConfigSaveSettings', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:saveSettings', false, data)
    cb(result or { ok = false, error = err or 'Unable to save settings.' })
end)

RegisterNUICallback('oxConfigReadFile', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:readFile', false, data and data.path)
    cb(result or { ok = false, error = err or 'Unable to read file.' })
end)

RegisterNUICallback('oxConfigSaveFile', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:saveFile', false, data and data.path, data and data.content)
    cb(result or { ok = false, error = err or 'Unable to save file.' })
end)

RegisterNUICallback('oxConfigUploadImage', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:uploadImage', false, data and data.name, data and data.dataUrl)
    cb(result or { ok = false, error = err or 'Unable to upload image.' })
end)

RegisterNUICallback('oxConfigDeleteImage', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:deleteImage', false, data and data.name)
    cb(result or { ok = false, error = err or 'Unable to delete image.' })
end)

RegisterNUICallback('oxConfigListImages', function(_, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:listImages', false)
    cb(result or { ok = false, error = err or 'Unable to list images.' })
end)

RegisterNUICallback('oxConfigRestart', function(_, cb)
    -- Close the CEF/NUI immediately before the resource restarts. Waiting for a
    -- server callback can leave the UI stuck if the resource stops mid-request.
    closeOxConfig()
    cb({ ok = true, message = 'Restart queued.' })
    SetTimeout(75, function()
        TriggerServerEvent('ox_inventory:oxconfig:restart')
    end)
end)

RegisterNUICallback('oxConfigGetPlayerCoords', function(_, cb)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    cb({
        ok = true,
        vec3 = ('vec3(%.2f, %.2f, %.2f)'):format(coords.x, coords.y, coords.z),
        vec4 = ('vec4(%.2f, %.2f, %.2f, %.2f)'):format(coords.x, coords.y, coords.z, heading),
        x = coords.x,
        y = coords.y,
        z = coords.z,
        h = heading,
    })
end)

RegisterNUICallback('oxConfigCreateItem', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:createItem', false, data)
    cb(result or { ok = false, error = err or 'Unable to create item.' })
end)

RegisterNUICallback('oxConfigAddShopItem', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:addShopItem', false, data)
    cb(result or { ok = false, error = err or 'Unable to add item to shop.' })
end)

RegisterNUICallback('oxConfigUpdateItem', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:updateItem', false, data)
    cb(result or { ok = false, error = err or 'Unable to update item.' })
end)


RegisterNUICallback('oxConfigMoveShopLocation', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:moveShopLocation', false, data)
    cb(result or { ok = false, error = err or 'Unable to move shop location.' })
end)

RegisterNUICallback('oxConfigAddShopLocation', function(data, cb)
    local result, err = lib.callback.await('ox_inventory:oxconfig:addShopLocation', false, data)
    cb(result or { ok = false, error = err or 'Unable to add shop location.' })
end)
