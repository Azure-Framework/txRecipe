local busy = false

local function log(msg)
    print(('[ox_inventory_restart_helper] %s'):format(msg))
end

local function closeUIs()
    TriggerClientEvent('ox_inventory:oxconfig:forceClose', -1)
    TriggerClientEvent('ox_inventory:closeInventory', -1, true)
    TriggerClientEvent('ox_inventory:closeInventory', -1)
end

RegisterNetEvent('ox_inventory_restart_helper:restart', function(targetResource, requestSource)
    local caller = GetInvokingResource()

    if caller ~= 'ox_inventory' then
        log(('blocked restart request from %s'):format(tostring(caller)))
        return
    end

    if busy then
        log('restart already in progress')
        return
    end

    targetResource = tostring(targetResource or 'ox_inventory')
    if targetResource == '' then targetResource = 'ox_inventory' end

    busy = true
    log(('hard restart requested by player %s for %s'):format(tostring(requestSource or 0), targetResource))

    closeUIs()

    SetTimeout(850, function()
        local before = GetResourceState(targetResource)
        log(('before stop: %s=%s'):format(targetResource, before))

        local stopOk, stopErr = pcall(StopResource, targetResource)
        log(('StopResource ok=%s result=%s state=%s'):format(tostring(stopOk), tostring(stopErr), GetResourceState(targetResource)))

        SetTimeout(1350, function()
            local startOk, startResult = pcall(StartResource, targetResource)
            log(('StartResource ok=%s result=%s state=%s'):format(tostring(startOk), tostring(startResult), GetResourceState(targetResource)))

            SetTimeout(1500, function()
                local state = GetResourceState(targetResource)
                if state ~= 'started' then
                    log(('native restart did not finish, trying ensure fallback. state=%s'):format(state))
                    ExecuteCommand(('ensure %s'):format(targetResource))
                end

                SetTimeout(1200, function()
                    log(('final state: %s=%s'):format(targetResource, GetResourceState(targetResource)))
                    busy = false
                end)
            end)
        end)
    end)
end)

RegisterCommand('oxinventoryhelperrestart', function(source)
    if source ~= 0 then return end
    TriggerEvent('ox_inventory_restart_helper:restart', 'ox_inventory', 0)
end, true)
