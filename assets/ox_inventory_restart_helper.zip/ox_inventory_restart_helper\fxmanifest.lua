fx_version 'cerulean'
game 'gta5'

name 'ox_inventory_restart_helper'
description 'Helper resource used by ox_inventory oxconfig to hard restart ox_inventory from outside itself.'
author 'MadeByAzure'
version '1.0.0'

server_script 'server.lua'
